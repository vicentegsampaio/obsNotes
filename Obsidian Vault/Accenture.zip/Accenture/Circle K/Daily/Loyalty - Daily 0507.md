#### **Done**
#### **Done**
- Matheus e Maurilio -> 
- Jeff e Vicente -> 
- Nunes, Laura e Maranhão ->
- Nath ->
- Alencar ->

#### **To Do**
- Matheus e Maurilio -> 
- Jeff e Vicente -> 
- Nunes, Laura e Maranhão ->
- Nath ->
- Alencar ->

#### **Summary**
- 
