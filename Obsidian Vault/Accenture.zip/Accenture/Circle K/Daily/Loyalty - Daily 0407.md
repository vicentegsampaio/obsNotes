#### **Done**
- Nunes -> Iniciou o card de carga dos arquivos
- 

#### **To Do**
-  EPCS - SERVICE FUNCTION - CARD STATUS TEST