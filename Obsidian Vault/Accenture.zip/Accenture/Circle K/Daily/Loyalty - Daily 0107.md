
#### **Done**
- Product space created by Circle K
- Sub-tasks created by Nunes on Jira
- 

#### **To Do**
-  Start tasks and nominate who's going to do it
- Understand how to use repos and work with git