
#### **Done**
- Alencar ->  
- Nunes -> Criação do contrato -> Sem repositorio não está pronto 
- Jeff -> resolvendo pendencia de acessos e verificar projetos atual existentes para estudar
- 

#### **To Do**
-  